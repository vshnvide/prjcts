# Group-4-e-placement-portal
Gandharvi Walavekar 20104045
Vaishnavi Shinde 20104002
Kanan Sananse 20104125
Shruti Pinjarkar 20104016
Training and management of placement is a crucial part of an educational
institution in which most of the work is done manually.From a student’s
perspective, placements can bring a wide range of benefits and opportunities. Manual system in the colleges requires a lot of manpower and time.With this
project we aim to develop an application to solve this issue.. With the Job search portals, the recruitment process is speed up at every stage
from job postings, to receiving applications from candidates, interviewing
process. The cost of searching/posting jobs will be much less compared to the
traditional way of advertising. Job search portal stands as an effective means
for Employers to outline the job vacancies, responsibilities and qualifications
to attract job seekers. It is a platform where students can view and assess their
opportunities